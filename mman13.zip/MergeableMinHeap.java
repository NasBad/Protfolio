import java.util.*;

class Node {
    int key;
    Node next;

    Node(int key) {
        this.key = key;
        this.next = null;
    }
}

class MergeableMinHeap {
    Node head;

    public void insert(int key) {
        Node newNode = new Node(key);
        if (head == null || key < head.key) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.key <= key) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void printHeap() {
        if (head == null) {
            System.out.println("Heap is empty");
            return;
        }
        List<Node> nodes = new ArrayList<>();
        Node current = head;
        while (current != null) {
            nodes.add(current);
            current = current.next;
        }
        printTree(nodes);
    }

    private void printTree(List<Node> nodes) {
        int height = (int) Math.ceil(Math.log(nodes.size() + 1) / Math.log(2));
        int maxNodes = (int) Math.pow(2, height) - 1;
        int maxWidth = maxNodes * 4;

        List<StringBuilder> treeLines = new ArrayList<>();
        for (int i = 0; i < height * 2 - 1; i++) {
            treeLines.add(new StringBuilder(String.format("%" + maxWidth + "s", "")));
        }

        for (int i = 0; i < nodes.size(); i++) {
            int level = (int) Math.floor(Math.log(i + 1) / Math.log(2));
            int indexAtLevel = i - (int) Math.pow(2, level) + 1;
            int spacing = maxWidth / (int) Math.pow(2, level + 1);
            int pos = indexAtLevel * spacing * 2 + spacing / 2;

            treeLines.get(level * 2).replace(pos, pos + 3, String.format("%-3d", nodes.get(i).key));

            if (level > 0) {
                int parentPos = ((i - 1) / 2 - (int) Math.pow(2, level - 1) + 1) * spacing * 2 + spacing / 2;
                if (i % 2 == 1) {
                    // Left child
                    treeLines.get(level * 2 - 1).replace(parentPos + 1, pos + 1, "-".repeat(pos - parentPos));
                    treeLines.get(level * 2 - 1).setCharAt(parentPos + 1, '/');
                } else {
                    // Right child
                    treeLines.get(level * 2 - 1).replace(parentPos + 1, pos + 1, "-".repeat(pos - parentPos));
                    treeLines.get(level * 2 - 1).setCharAt(pos, '\\');
                }
            }
        }

        for (StringBuilder line : treeLines) {
            System.out.println(line.toString());
        }
    }

    public void union(MergeableMinHeap otherHeap) {
        if (otherHeap.head == null) {
            return;
        }
        if (head == null) {
            head = otherHeap.head;
            otherHeap.head = null;
            return;
        }

        Node dummy = new Node(-1); // dummy node to simplify merging
        Node tail = dummy;
        Node h1 = head;
        Node h2 = otherHeap.head;

        while (h1 != null && h2 != null) {
            if (h1.key <= h2.key) {
                tail.next = h1;
                h1 = h1.next;
            } else {
                tail.next = h2;
                h2 = h2.next;
            }
            tail = tail.next;
        }

        if (h1 != null) {
            tail.next = h1;
        } else {
            tail.next = h2;
        }

        head = dummy.next; // set the new head to the merged list
        otherHeap.head = null; // clear the other heap
    }

    public static void main(String[] args) {
        MergeableMinHeap heap = new MergeableMinHeap();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter keys to insert into the heap (separated by spaces):");
        String[] keys = scanner.nextLine().split(" ");
        for (String key : keys) {
            heap.insert(Integer.parseInt(key));
        }

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Minimum");
            System.out.println("2. Extract Min");
            System.out.println("3. Union");
            System.out.println("4. Print Heap");
            System.out.println("5. Insert");
            System.out.println("6. Quit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Minimum
                    if (heap.head != null) {
                        System.out.println("Minimum: " + heap.head.key);
                    } else {
                        System.out.println("Heap is empty");
                    }
                    break;
                case 2:
                    // Extract Min
                    if (heap.head != null) {
                        System.out.println("Extracted Min: " + heap.head.key);
                        heap.head = heap.head.next;
                    } else {
                        System.out.println("Heap is empty");
                    }
                    break;
                case 3:
                    // Union
                    System.out.println("Enter keys to insert into the other heap (separated by spaces):");
                    scanner.nextLine(); // consume the newline
                    String[] otherKeys = scanner.nextLine().split(" ");
                    MergeableMinHeap otherHeap = new MergeableMinHeap();
                    for (String key : otherKeys) {
                        otherHeap.insert(Integer.parseInt(key));
                    }
                    heap.union(otherHeap);
                    break;
                case 4:
                    // Print Heap
                    heap.printHeap();
                    break;
                case 5:
                    // Insert
                    System.out.println("Enter a key to insert:");
                    int key = scanner.nextInt();
                    heap.insert(key);
                    break;
                case 6:
                    // Quit
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
